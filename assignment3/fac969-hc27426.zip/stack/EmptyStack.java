package stack;

// This is the exception throwed when try to pop an
// element from an empty stack.
public class EmptyStack extends java.lang.Exception {
  public EmptyStack() {
    super ();
  }
  
}
